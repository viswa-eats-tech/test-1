"""
database.py — SQLAlchemy + SQLite setup
"""
from sqlalchemy import (
    create_engine, Column, Integer, Float, String, DateTime
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_URL = f"sqlite:///{os.path.join(BASE_DIR, 'data', 'japan_labor.db')}"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


# ── Table: Historical labor data ──────────────────
class LaborData(Base):
    __tablename__ = "labor_data"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    year = Column(Integer, nullable=False)
    prefecture = Column(String(50), nullable=False)
    sector = Column(String(50), nullable=False)
    employed_count = Column(Float)
    labor_force_participation_rate = Column(Float)
    population_65plus_pct = Column(Float)
    birth_rate = Column(Float)
    job_openings_ratio = Column(Float)
    shortage_index = Column(Float)


# ── Table: Cached predictions ─────────────────────
class Prediction(Base):
    __tablename__ = "predictions"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    prefecture = Column(String(50), nullable=False)
    sector = Column(String(50), nullable=False)
    year = Column(Integer, nullable=False)
    shortage_index = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)


# ── Initialization ─────────────────────────────────
def init_db():
    """Create all tables if they don't exist."""
    Base.metadata.create_all(bind=engine)


def get_db():
    """FastAPI dependency — yields a DB session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
