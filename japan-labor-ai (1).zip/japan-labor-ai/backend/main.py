"""
main.py — FastAPI application for Japan Labor Crisis Predictor
"""
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
from sqlalchemy.orm import Session
import os, joblib, json, pandas as pd, numpy as np

from database import init_db, get_db, LaborData

# ── Paths ──────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, "data", "models")
DATA_DIR = os.path.join(BASE_DIR, "data", "processed")

# ── Prefectures & Sectors ─────────────────────────
PREFECTURES = [
    "Hokkaido", "Aomori", "Iwate", "Miyagi", "Akita", "Yamagata", "Fukushima",
    "Ibaraki", "Tochigi", "Gunma", "Saitama", "Chiba", "Tokyo", "Kanagawa",
    "Niigata", "Toyama", "Ishikawa", "Fukui", "Yamanashi", "Nagano",
    "Gifu", "Shizuoka", "Aichi", "Mie", "Shiga", "Kyoto", "Osaka", "Hyogo",
    "Nara", "Wakayama", "Tottori", "Shimane", "Okayama", "Hiroshima",
    "Yamaguchi", "Tokushima", "Kagawa", "Ehime", "Kochi", "Fukuoka",
    "Saga", "Nagasaki", "Kumamoto", "Oita", "Miyazaki", "Kagoshima", "Okinawa"
]

SECTORS = [
    "Healthcare", "Manufacturing", "Construction", "IT/Technology",
    "Retail", "Agriculture", "Education", "Transportation",
    "Hospitality", "Finance"
]

# ── Pydantic schemas ──────────────────────────────
class PredictRequest(BaseModel):
    prefecture: str
    sector: str
    year_range: List[int]  # [start_year, end_year]

class PredictionPoint(BaseModel):
    year: int
    shortage_index: float

class PredictResponse(BaseModel):
    predictions: List[PredictionPoint]
    severity_label: str
    trend: str

class AgentRequest(BaseModel):
    prefecture: str
    sector: str
    predictions: List[PredictionPoint]
    severity_label: str

class AgentRecommendation(BaseModel):
    agentic_ai_solutions: List[str]
    policy_interventions: List[str]
    business_actions: List[str]

class AgentResponse(BaseModel):
    recommendations: AgentRecommendation
    reasoning: str

class HeatmapPoint(BaseModel):
    prefecture: str
    shortage_index: float

# ── App ────────────────────────────────────────────
app = FastAPI(
    title="Japan Labor Crisis Predictor & Agentic Policy Advisor",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup():
    init_db()


# ── Helper: load model artifacts ──────────────────
def _load_model():
    model_path = os.path.join(MODEL_DIR, "xgboost_model.pkl")
    encoders_path = os.path.join(MODEL_DIR, "label_encoders.pkl")
    scaler_path = os.path.join(MODEL_DIR, "scaler.pkl")
    if not os.path.exists(model_path):
        raise HTTPException(status_code=500, detail="Model not trained yet. Run train_xgboost.py first.")
    model = joblib.load(model_path)
    encoders = joblib.load(encoders_path)
    scaler = joblib.load(scaler_path)
    return model, encoders, scaler


def _severity_label(score: float) -> str:
    if score >= 70:
        return "Critical"
    elif score >= 50:
        return "Severe"
    elif score >= 30:
        return "Moderate"
    else:
        return "Low"


def _trend(predictions: list) -> str:
    if len(predictions) < 2:
        return "stable"
    first_half = np.mean([p["shortage_index"] for p in predictions[:len(predictions)//2]])
    second_half = np.mean([p["shortage_index"] for p in predictions[len(predictions)//2:]])
    diff = second_half - first_half
    if diff > 3:
        return "worsening"
    elif diff < -3:
        return "improving"
    return "stable"


# ── Routes ─────────────────────────────────────────
@app.get("/prefectures", response_model=List[str])
def get_prefectures():
    return PREFECTURES


@app.get("/sectors", response_model=List[str])
def get_sectors():
    return SECTORS


@app.post("/predict", response_model=PredictResponse)
def predict(req: PredictRequest):
    model, encoders, scaler = _load_model()

    pref_enc = encoders["prefecture"]
    sect_enc = encoders["sector"]

    if req.prefecture not in pref_enc.classes_:
        raise HTTPException(status_code=400, detail=f"Unknown prefecture: {req.prefecture}")
    if req.sector not in sect_enc.classes_:
        raise HTTPException(status_code=400, detail=f"Unknown sector: {req.sector}")

    # Load historical data to extract latest demographic features
    df = pd.read_csv(os.path.join(DATA_DIR, "labor_data.csv"))
    subset = df[(df["prefecture"] == req.prefecture) & (df["sector"] == req.sector)]
    if subset.empty:
        raise HTTPException(status_code=404, detail="No data for this combination.")

    latest = subset.sort_values("year").iloc[-1]

    predictions = []
    start_yr, end_yr = req.year_range[0], req.year_range[1]

    for yr in range(start_yr, end_yr + 1):
        # Extrapolate demographic features linearly
        years_ahead = yr - int(latest["year"])
        pop_65 = latest["population_65plus_pct"] + years_ahead * 0.55
        birth = max(latest["birth_rate"] - years_ahead * 0.01, 0.8)
        lfpr = max(latest["labor_force_participation_rate"] - years_ahead * 0.002, 0.40)
        jor = latest["job_openings_ratio"] + years_ahead * 0.04

        features = pd.DataFrame([{
            "year": yr,
            "prefecture_encoded": pref_enc.transform([req.prefecture])[0],
            "sector_encoded": sect_enc.transform([req.sector])[0],
            "population_65plus_pct": pop_65,
            "birth_rate": birth,
            "labor_force_participation_rate": lfpr,
            "job_openings_ratio": jor,
        }])

        features_scaled = scaler.transform(features)
        pred = model.predict(features_scaled)[0]
        pred = float(np.clip(pred, 0, 100))
        predictions.append({"year": yr, "shortage_index": round(pred, 2)})

    severity = _severity_label(predictions[-1]["shortage_index"])
    trend_dir = _trend(predictions)

    return PredictResponse(
        predictions=[PredictionPoint(**p) for p in predictions],
        severity_label=severity,
        trend=trend_dir,
    )


@app.post("/agent/recommend", response_model=AgentResponse)
def agent_recommend(req: AgentRequest):
    """
    Calls the LangChain + Ollama agent.
    Falls back to a rule-based engine if Ollama is unavailable.
    """
    try:
        from agent.advisor_agent import get_recommendations
        result = get_recommendations(
            prefecture=req.prefecture,
            sector=req.sector,
            predictions=[p.model_dump() for p in req.predictions],
            severity_label=req.severity_label,
        )
        return AgentResponse(**result)
    except Exception as e:
        # Fallback: rule-based recommendations
        return _fallback_recommendations(req)


def _fallback_recommendations(req: AgentRequest) -> AgentResponse:
    """Rule-based fallback when Ollama is not running."""
    sector = req.sector
    severity = req.severity_label
    prefecture = req.prefecture
    avg_score = np.mean([p.shortage_index for p in req.predictions])

    ai_solutions = {
        "Healthcare": [
            "Autonomous patient monitoring agents for elderly care facilities",
            "AI-powered triage and diagnosis support agents",
            "Robotic process automation for medical record management",
            "AI scheduling agents to optimize staff allocation",
        ],
        "Manufacturing": [
            "Predictive maintenance AI agents for factory equipment",
            "Collaborative robot (cobot) coordination agents",
            "Quality inspection automation via computer vision agents",
            "Supply chain optimization AI agents",
        ],
        "Construction": [
            "Autonomous site inspection drone agents",
            "AI project scheduling and resource allocation agents",
            "Safety monitoring agents using computer vision",
            "BIM (Building Information Modeling) AI assistants",
        ],
        "IT/Technology": [
            "AI code review and testing agents",
            "Automated DevOps pipeline agents",
            "AI-powered customer support chatbots",
            "Intelligent document processing agents",
        ],
        "Retail": [
            "Automated inventory management agents",
            "AI-powered customer service and checkout agents",
            "Demand forecasting AI agents",
            "Personalized marketing recommendation agents",
        ],
        "Agriculture": [
            "Autonomous crop monitoring drone agents",
            "AI-powered irrigation and fertilization agents",
            "Harvest prediction and planning agents",
            "Livestock health monitoring AI agents",
        ],
        "Education": [
            "AI tutoring and personalized learning agents",
            "Automated grading and feedback agents",
            "Administrative task automation agents",
            "Student engagement monitoring agents",
        ],
        "Transportation": [
            "Autonomous vehicle fleet management agents",
            "AI route optimization and logistics agents",
            "Predictive maintenance agents for transport infrastructure",
            "Smart traffic management AI agents",
        ],
        "Hospitality": [
            "AI concierge and guest service agents",
            "Automated booking and revenue management agents",
            "Multilingual AI communication agents for tourism",
            "Kitchen automation and food service AI agents",
        ],
        "Finance": [
            "AI fraud detection and compliance agents",
            "Automated financial advisory agents",
            "Document processing and KYC verification agents",
            "Risk assessment and credit scoring AI agents",
        ],
    }

    policy_map = {
        "Critical": [
            f"Declare {sector} in {prefecture} a priority labor shortage sector",
            "Expand Technical Intern Training Program (TITP) quotas for this sector",
            "Offer tax incentives for companies investing in automation",
            "Fast-track Specified Skilled Worker (SSW) visa for this sector",
            "Fund regional AI adoption centers under Society 5.0 initiative",
        ],
        "Severe": [
            f"Increase subsidies for {sector} workforce training in {prefecture}",
            "Expand childcare support to boost female labor participation",
            "Create regional immigration fast-track programs",
            "Fund joint university-industry AI research for this sector",
        ],
        "Moderate": [
            f"Monitor {sector} labor trends in {prefecture} quarterly",
            "Invest in vocational training and reskilling programs",
            "Promote remote work policies to attract talent from other prefectures",
        ],
        "Low": [
            "Maintain current labor market monitoring",
            "Continue supporting workforce development programs",
        ],
    }

    business_map = {
        "Critical": [
            "Immediately invest in AI and robotic automation for core operations",
            "Partner with overseas recruitment agencies",
            "Redesign workflows to reduce human-dependent bottlenecks",
            "Offer above-market wages and retention bonuses",
            "Implement flexible work arrangements to attract diverse talent",
        ],
        "Severe": [
            "Begin piloting AI agent solutions for repetitive tasks",
            "Develop internal upskilling programs",
            "Explore partnerships with vocational schools",
            "Offer competitive relocation packages",
        ],
        "Moderate": [
            "Plan for gradual automation of routine processes",
            "Invest in employee retention and satisfaction programs",
            "Build relationships with educational institutions",
        ],
        "Low": [
            "Focus on long-term workforce planning",
            "Stay informed about AI tools relevant to your sector",
        ],
    }

    reasoning = (
        f"Analysis for {prefecture} - {sector} sector:\n"
        f"The predicted average shortage index is {avg_score:.1f}/100, "
        f"classified as \"{severity}\". "
    )
    if severity in ("Critical", "Severe"):
        reasoning += (
            f"This indicates a significant labor gap driven by Japan's aging demographics "
            f"(31.4% over 65 by 2025) and declining birth rate. "
            f"Immediate intervention through Agentic AI deployment, policy reform aligned "
            f"with Society 5.0, and strategic business transformation is essential."
        )
    else:
        reasoning += (
            f"While not immediately critical, proactive measures should be taken to "
            f"prevent escalation, particularly given Japan's long-term demographic trajectory."
        )

    return AgentResponse(
        recommendations=AgentRecommendation(
            agentic_ai_solutions=ai_solutions.get(sector, ai_solutions["IT/Technology"]),
            policy_interventions=policy_map.get(severity, policy_map["Moderate"]),
            business_actions=business_map.get(severity, business_map["Moderate"]),
        ),
        reasoning=reasoning,
    )


@app.get("/heatmap", response_model=List[HeatmapPoint])
def get_heatmap():
    csv_path = os.path.join(DATA_DIR, "labor_data.csv")
    if not os.path.exists(csv_path):
        raise HTTPException(status_code=500, detail="Data file not found. Run data generation first.")
    df = pd.read_csv(csv_path)
    latest_year = df["year"].max()
    latest = df[df["year"] == latest_year]
    heatmap = (
        latest.groupby("prefecture")["shortage_index"]
        .mean()
        .reset_index()
        .round(2)
    )
    return [
        HeatmapPoint(prefecture=row["prefecture"], shortage_index=row["shortage_index"])
        for _, row in heatmap.iterrows()
    ]


# ── Run ────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
