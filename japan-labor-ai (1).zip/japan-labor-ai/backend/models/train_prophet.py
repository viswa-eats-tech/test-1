"""
train_prophet.py — Train Prophet time-series models per sector
Forecasts employment shortage trends from 2024–2035.
"""
import os
import pandas as pd
import joblib
from prophet import Prophet
import warnings

warnings.filterwarnings("ignore")

# ── Paths ──────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(BASE_DIR, "data", "processed", "labor_data.csv")
MODEL_DIR = os.path.join(BASE_DIR, "data", "models")
os.makedirs(MODEL_DIR, exist_ok=True)


def train_all_sectors():
    print("=" * 60)
    print("  Prophet Training — Sector-level Time-Series Forecast")
    print("=" * 60)

    df = pd.read_csv(DATA_PATH)
    sectors = df["sector"].unique()

    print(f"\n📊 Loaded {len(df):,} rows, {len(sectors)} sectors")

    forecasts = {}

    for sector in sectors:
        print(f"\n── Training Prophet for: {sector} ──")

        # Aggregate: mean shortage_index per year for this sector
        sector_df = (
            df[df["sector"] == sector]
            .groupby("year")["shortage_index"]
            .mean()
            .reset_index()
        )

        # Prophet requires columns named 'ds' (date) and 'y' (value)
        prophet_df = pd.DataFrame({
            "ds": pd.to_datetime(sector_df["year"], format="%Y"),
            "y": sector_df["shortage_index"],
        })

        # Train Prophet
        model = Prophet(
            yearly_seasonality=False,
            weekly_seasonality=False,
            daily_seasonality=False,
            changepoint_prior_scale=0.1,
        )
        model.fit(prophet_df)

        # Forecast 2024–2035 (12 years ahead)
        future = model.make_future_dataframe(periods=12, freq="YS")
        forecast = model.predict(future)

        forecast_out = forecast[["ds", "yhat", "yhat_lower", "yhat_upper"]].copy()
        forecast_out["year"] = forecast_out["ds"].dt.year
        forecasts[sector] = forecast_out

        # Save model
        model_path = os.path.join(MODEL_DIR, f"prophet_{sector.replace('/', '_')}.pkl")
        joblib.dump(model, model_path)
        print(f"   💾 Saved → {model_path}")

        # Show forecast for future years
        future_rows = forecast_out[forecast_out["year"] >= 2024]
        for _, row in future_rows.iterrows():
            print(f"   {int(row['year'])}: shortage_index = {row['yhat']:.2f} "
                  f"[{row['yhat_lower']:.2f}, {row['yhat_upper']:.2f}]")

    # Save all forecasts as a single CSV for easy access
    all_forecasts = []
    for sector, fc in forecasts.items():
        fc = fc.copy()
        fc["sector"] = sector
        all_forecasts.append(fc)

    combined = pd.concat(all_forecasts, ignore_index=True)
    combined.to_csv(os.path.join(MODEL_DIR, "prophet_forecasts.csv"), index=False)
    print(f"\n💾 Combined forecasts saved → prophet_forecasts.csv")
    print("\n✅ All Prophet models trained!")


if __name__ == "__main__":
    train_all_sectors()
