"""
predict.py — Utility functions for loading models and making predictions
"""
import os
import pandas as pd
import numpy as np
import joblib

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_DIR = os.path.join(BASE_DIR, "data", "models")
DATA_DIR = os.path.join(BASE_DIR, "data", "processed")


def load_xgboost_model():
    """Load the trained XGBoost model, label encoders, and scaler."""
    model = joblib.load(os.path.join(MODEL_DIR, "xgboost_model.pkl"))
    encoders = joblib.load(os.path.join(MODEL_DIR, "label_encoders.pkl"))
    scaler = joblib.load(os.path.join(MODEL_DIR, "scaler.pkl"))
    return model, encoders, scaler


def predict_shortage(prefecture: str, sector: str, year_range: list) -> list:
    """
    Predict shortage_index for a prefecture-sector combo over a year range.

    Args:
        prefecture: Name of the Japanese prefecture
        sector: Industry sector name
        year_range: [start_year, end_year]

    Returns:
        List of dicts: [{"year": int, "shortage_index": float}, ...]
    """
    model, encoders, scaler = load_xgboost_model()

    pref_enc = encoders["prefecture"]
    sect_enc = encoders["sector"]

    # Load historical data for latest demographics
    df = pd.read_csv(os.path.join(DATA_DIR, "labor_data.csv"))
    subset = df[(df["prefecture"] == prefecture) & (df["sector"] == sector)]
    latest = subset.sort_values("year").iloc[-1]

    predictions = []
    start_yr, end_yr = year_range

    for yr in range(start_yr, end_yr + 1):
        years_ahead = yr - int(latest["year"])

        # Extrapolate demographics
        pop_65 = latest["population_65plus_pct"] + years_ahead * 0.55
        birth = max(latest["birth_rate"] - years_ahead * 0.01, 0.8)
        lfpr = max(latest["labor_force_participation_rate"] - years_ahead * 0.002, 0.40)
        jor = latest["job_openings_ratio"] + years_ahead * 0.04

        features = pd.DataFrame([{
            "year": yr,
            "prefecture_encoded": pref_enc.transform([prefecture])[0],
            "sector_encoded": sect_enc.transform([sector])[0],
            "population_65plus_pct": pop_65,
            "birth_rate": birth,
            "labor_force_participation_rate": lfpr,
            "job_openings_ratio": jor,
        }])

        features_scaled = scaler.transform(features)
        pred = float(np.clip(model.predict(features_scaled)[0], 0, 100))
        predictions.append({"year": yr, "shortage_index": round(pred, 2)})

    return predictions


def load_prophet_model(sector: str):
    """Load a trained Prophet model for a specific sector."""
    safe_name = sector.replace("/", "_")
    model_path = os.path.join(MODEL_DIR, f"prophet_{safe_name}.pkl")
    return joblib.load(model_path)


def prophet_forecast(sector: str) -> pd.DataFrame:
    """
    Get Prophet forecast for a sector.
    Returns DataFrame with columns: year, yhat, yhat_lower, yhat_upper
    """
    forecasts_path = os.path.join(MODEL_DIR, "prophet_forecasts.csv")
    if os.path.exists(forecasts_path):
        df = pd.read_csv(forecasts_path)
        sector_df = df[df["sector"] == sector][["year", "yhat", "yhat_lower", "yhat_upper"]]
        return sector_df[sector_df["year"] >= 2024].reset_index(drop=True)

    # Fallback: load model and predict
    model = load_prophet_model(sector)
    future = model.make_future_dataframe(periods=12, freq="YS")
    forecast = model.predict(future)
    forecast["year"] = forecast["ds"].dt.year
    return forecast[forecast["year"] >= 2024][["year", "yhat", "yhat_lower", "yhat_upper"]].reset_index(drop=True)
