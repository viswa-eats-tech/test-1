"""
train_xgboost.py — Train XGBoost regression model for shortage_index prediction
"""
import os
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import mean_squared_error, r2_score
from xgboost import XGBRegressor
import joblib

# ── Paths ──────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(BASE_DIR, "data", "processed", "labor_data.csv")
MODEL_DIR = os.path.join(BASE_DIR, "data", "models")
os.makedirs(MODEL_DIR, exist_ok=True)


def train():
    print("=" * 60)
    print("  XGBoost Training — Japan Labor Shortage Predictor")
    print("=" * 60)

    # ── Load data ──────────────────────────────────
    df = pd.read_csv(DATA_PATH)
    print(f"\n📊 Loaded {len(df):,} rows from {DATA_PATH}")
    print(f"   Columns: {list(df.columns)}")

    # ── Encode categorical features ────────────────
    le_prefecture = LabelEncoder()
    le_sector = LabelEncoder()

    df["prefecture_encoded"] = le_prefecture.fit_transform(df["prefecture"])
    df["sector_encoded"] = le_sector.fit_transform(df["sector"])

    # ── Define features and target ─────────────────
    FEATURE_COLS = [
        "year",
        "prefecture_encoded",
        "sector_encoded",
        "population_65plus_pct",
        "birth_rate",
        "labor_force_participation_rate",
        "job_openings_ratio",
    ]
    TARGET = "shortage_index"

    X = df[FEATURE_COLS].copy()
    y = df[TARGET].copy()

    print(f"\n📐 Features ({len(FEATURE_COLS)}): {FEATURE_COLS}")
    print(f"   Target   : {TARGET}")
    print(f"   X shape  : {X.shape}")

    # ── Scale features ─────────────────────────────
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # ── Train/Test split ───────────────────────────
    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42
    )
    print(f"\n🔀 Split: {len(X_train):,} train / {len(X_test):,} test")

    # ── Train XGBoost ──────────────────────────────
    model = XGBRegressor(
        n_estimators=500,
        max_depth=6,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        reg_alpha=0.1,
        reg_lambda=1.0,
        random_state=42,
        n_jobs=-1,
    )

    print("\n🚀 Training XGBoost...")
    model.fit(
        X_train, y_train,
        eval_set=[(X_test, y_test)],
        verbose=50,
    )

    # ── Evaluate ───────────────────────────────────
    y_pred = model.predict(X_test)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    r2 = r2_score(y_test, y_pred)

    print(f"\n📈 Evaluation Results:")
    print(f"   RMSE : {rmse:.4f}")
    print(f"   R²   : {r2:.4f}")

    # ── Feature importance ─────────────────────────
    importances = model.feature_importances_
    print(f"\n🏆 Feature Importance:")
    for name, imp in sorted(zip(FEATURE_COLS, importances), key=lambda x: -x[1]):
        print(f"   {name:40s} {imp:.4f}")

    # ── Save artifacts ─────────────────────────────
    joblib.dump(model, os.path.join(MODEL_DIR, "xgboost_model.pkl"))
    joblib.dump(
        {"prefecture": le_prefecture, "sector": le_sector},
        os.path.join(MODEL_DIR, "label_encoders.pkl"),
    )
    joblib.dump(scaler, os.path.join(MODEL_DIR, "scaler.pkl"))

    print(f"\n💾 Saved to {MODEL_DIR}:")
    print(f"   • xgboost_model.pkl")
    print(f"   • label_encoders.pkl")
    print(f"   • scaler.pkl")
    print("\n✅ Training complete!")

    return model, rmse, r2


if __name__ == "__main__":
    train()
