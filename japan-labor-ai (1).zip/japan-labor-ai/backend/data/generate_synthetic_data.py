"""
generate_synthetic_data.py
Generates realistic synthetic labor-market data for all 47 Japanese
prefectures × 10 industry sectors × years 2005-2023.
"""
import pandas as pd
import numpy as np
import os

np.random.seed(42)

# ── All 47 prefectures ────────────────────────────
PREFECTURES = [
    "Hokkaido", "Aomori", "Iwate", "Miyagi", "Akita", "Yamagata", "Fukushima",
    "Ibaraki", "Tochigi", "Gunma", "Saitama", "Chiba", "Tokyo", "Kanagawa",
    "Niigata", "Toyama", "Ishikawa", "Fukui", "Yamanashi", "Nagano",
    "Gifu", "Shizuoka", "Aichi", "Mie", "Shiga", "Kyoto", "Osaka", "Hyogo",
    "Nara", "Wakayama", "Tottori", "Shimane", "Okayama", "Hiroshima",
    "Yamaguchi", "Tokushima", "Kagawa", "Ehime", "Kochi", "Fukuoka",
    "Saga", "Nagasaki", "Kumamoto", "Oita", "Miyazaki", "Kagoshima", "Okinawa"
]

SECTORS = [
    "Healthcare", "Manufacturing", "Construction", "IT/Technology",
    "Retail", "Agriculture", "Education", "Transportation",
    "Hospitality", "Finance"
]

YEARS = list(range(2005, 2024))  # 2005–2023

# ── Prefecture-level aging / urbanization profile ─
# Higher = more aged / rural  →  worse shortage
PREFECTURE_AGING_BIAS = {}
highly_aged = {"Akita", "Yamaguchi", "Shimane", "Kochi", "Tokushima",
               "Aomori", "Iwate", "Wakayama", "Tottori", "Nagasaki"}
urban = {"Tokyo", "Osaka", "Kanagawa", "Aichi", "Saitama", "Chiba",
         "Fukuoka", "Hyogo", "Kyoto", "Shizuoka"}

for p in PREFECTURES:
    if p in highly_aged:
        PREFECTURE_AGING_BIAS[p] = np.random.uniform(0.06, 0.10)
    elif p in urban:
        PREFECTURE_AGING_BIAS[p] = np.random.uniform(-0.04, 0.00)
    else:
        PREFECTURE_AGING_BIAS[p] = np.random.uniform(0.00, 0.05)

# ── Sector-level shortage tendency ─────────────────
SECTOR_SHORTAGE_BIAS = {
    "Healthcare": 0.15, "Manufacturing": 0.05, "Construction": 0.12,
    "IT/Technology": -0.02, "Retail": 0.03, "Agriculture": 0.18,
    "Education": 0.00, "Transportation": 0.10, "Hospitality": 0.08,
    "Finance": -0.03,
}

rows = []

for pref in PREFECTURES:
    for sector in SECTORS:
        for year in YEARS:
            t = year - 2005  # 0..18

            # population_65plus_pct: starts ~20-24%, rises to ~28-34%
            base_aging = 20.0 + PREFECTURE_AGING_BIAS[pref] * 100
            pop_65 = base_aging + t * np.random.uniform(0.45, 0.70) + np.random.normal(0, 0.3)
            pop_65 = np.clip(pop_65, 15, 42)

            # birth_rate: ~1.4 in 2005 → ~1.2 in 2023
            birth = 1.40 - t * 0.012 + np.random.normal(0, 0.03)
            birth = np.clip(birth, 0.9, 1.7)

            # labor_force_participation_rate: 58-65%, slight decline in aged prefectures
            lfpr_base = 0.62 if pref not in highly_aged else 0.56
            lfpr = lfpr_base - t * 0.002 + np.random.normal(0, 0.01)
            lfpr = np.clip(lfpr, 0.45, 0.72)

            # job_openings_ratio: starts ~0.8, rises to ~1.5+ by 2023
            jor = 0.80 + t * 0.045 + SECTOR_SHORTAGE_BIAS[sector] + np.random.normal(0, 0.05)
            jor = np.clip(jor, 0.4, 2.5)

            # employed_count (thousands): varies by prefecture size × sector
            size_factor = 50 if pref in urban else 15
            employed = size_factor * np.random.uniform(0.5, 2.0) * (1 - t * 0.005)
            employed = max(employed, 2)

            # shortage_index (target):
            # = jor * (1 - lfpr) * aging_factor, normalized 0–100
            aging_factor = pop_65 / 30.0  # ~1.0 when 30%
            raw = jor * (1 - lfpr) * aging_factor
            # raw typically ranges 0.2 – 1.8; normalize to 0–100
            shortage_index = np.clip(raw / 2.0 * 100, 0, 100)

            rows.append({
                "year": year,
                "prefecture": pref,
                "sector": sector,
                "employed_count": round(employed, 1),
                "labor_force_participation_rate": round(lfpr, 4),
                "population_65plus_pct": round(pop_65, 2),
                "birth_rate": round(birth, 3),
                "job_openings_ratio": round(jor, 3),
                "shortage_index": round(shortage_index, 2),
            })

df = pd.DataFrame(rows)

# ── Save ───────────────────────────────────────────
out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "processed")
os.makedirs(out_dir, exist_ok=True)
out_path = os.path.join(out_dir, "labor_data.csv")
df.to_csv(out_path, index=False)

print(f"✅ Generated {len(df):,} rows  →  {out_path}")
print(f"   Prefectures: {df['prefecture'].nunique()}")
print(f"   Sectors    : {df['sector'].nunique()}")
print(f"   Years      : {df['year'].min()} – {df['year'].max()}")
print(df.head(5))
