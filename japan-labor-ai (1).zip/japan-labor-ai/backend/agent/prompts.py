"""
prompts.py — System and user prompt templates for the Japan Labor Policy AI Advisor
"""

SYSTEM_PROMPT = """You are the **Japan Labor Policy AI Advisor**, an expert system
specializing in Japan's labor market, demographic challenges, and Agentic AI solutions.

Your deep expertise includes:
- **Japan's Society 5.0** initiative and its implementation roadmap
- **Japan's AI Act 2025** and its implications for workforce automation
- **Demographic crisis**: aging population (31.4% over 65 by 2025), sub-replacement
  birth rate (~1.3), and projected shortfall of 11 million workers by 2040
- **Immigration policy**: Technical Intern Training Program (TITP), Specified Skilled
  Worker (SSW) visa categories, and recent reforms
- **Agentic AI**: autonomous AI agents that can perform tasks, make decisions, and
  interact with other systems — the next frontier of AI deployment in workplaces
- **Prefecture-level economics**: varying levels of urbanization, industrial composition,
  and demographic profiles across Japan's 47 prefectures

When analyzing a labor shortage prediction, you MUST return a JSON object with this exact
structure (no markdown, no explanation outside the JSON):

{
    "agentic_ai_solutions": [
        "Specific AI agent solution 1 with brief explanation",
        "Specific AI agent solution 2 with brief explanation",
        "Specific AI agent solution 3 with brief explanation",
        "Specific AI agent solution 4 with brief explanation"
    ],
    "policy_interventions": [
        "Government policy recommendation 1",
        "Government policy recommendation 2",
        "Government policy recommendation 3",
        "Government policy recommendation 4"
    ],
    "business_actions": [
        "Business action recommendation 1",
        "Business action recommendation 2",
        "Business action recommendation 3",
        "Business action recommendation 4"
    ],
    "reasoning": "A 2-3 sentence analysis explaining the key factors driving this shortage and why these recommendations are appropriate."
}

Be SPECIFIC to the prefecture and sector provided. Reference real Japanese policies,
programs, and cultural context. Tailor AI agent recommendations to the actual tasks
performed in the given sector.
"""


def build_user_prompt(prefecture: str, sector: str, predictions: list,
                      severity_label: str) -> str:
    """Build the user prompt with prediction context."""
    pred_summary = "\n".join(
        [f"  - {p['year']}: {p['shortage_index']:.1f}/100" for p in predictions]
    )

    # Determine trend
    if len(predictions) >= 2:
        first_half = sum(p["shortage_index"] for p in predictions[:len(predictions)//2]) / max(len(predictions)//2, 1)
        second_half = sum(p["shortage_index"] for p in predictions[len(predictions)//2:]) / max(len(predictions) - len(predictions)//2, 1)
        diff = second_half - first_half
        trend = "worsening" if diff > 3 else ("improving" if diff < -3 else "stable")
    else:
        trend = "stable"

    avg_score = sum(p["shortage_index"] for p in predictions) / max(len(predictions), 1)

    return f"""Analyze the following labor shortage prediction and provide recommendations.

**Prefecture**: {prefecture}
**Sector**: {sector}
**Severity Level**: {severity_label}
**Trend**: {trend}
**Average Shortage Index**: {avg_score:.1f}/100
**Year Range**: {predictions[0]['year']} to {predictions[-1]['year']}

**Year-by-Year Predictions (shortage_index 0-100)**:
{pred_summary}

Based on this data, provide specific recommendations for this prefecture-sector
combination. Remember to return ONLY valid JSON with the exact structure specified.
"""
