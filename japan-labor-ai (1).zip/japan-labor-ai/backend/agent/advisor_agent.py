"""
advisor_agent.py — LangChain + Ollama agent for policy recommendations
"""
import json
import re
from typing import List, Dict, Any
from langchain_community.chat_models import ChatOllama
from langchain_core.messages import SystemMessage, HumanMessage
from agent.prompts import SYSTEM_PROMPT, build_user_prompt


def _parse_json_response(text: str) -> dict:
    """Extract JSON from the LLM response, handling markdown code blocks."""
    # Try to find JSON in code blocks first
    json_match = re.search(r"```(?:json)?\s*\n?(\{.*?\})\s*```", text, re.DOTALL)
    if json_match:
        return json.loads(json_match.group(1))

    # Try to find raw JSON object
    json_match = re.search(r"(\{.*\})", text, re.DOTALL)
    if json_match:
        return json.loads(json_match.group(1))

    raise ValueError(f"Could not parse JSON from response: {text[:500]}")


def get_recommendations(
    prefecture: str,
    sector: str,
    predictions: List[Dict[str, Any]],
    severity_label: str,
    model_name: str = "llama3.1",
    base_url: str = "http://localhost:11434",
) -> dict:
    """
    Call the Ollama LLM via LangChain to get structured recommendations.

    Args:
        prefecture: Japanese prefecture name
        sector: Industry sector
        predictions: List of {"year": int, "shortage_index": float}
        severity_label: "Critical", "Severe", "Moderate", or "Low"
        model_name: Ollama model to use (default: llama3.1)
        base_url: Ollama server URL

    Returns:
        Dict with keys: recommendations (dict), reasoning (str)
    """
    # Initialize the Ollama chat model via LangChain
    llm = ChatOllama(
        model=model_name,
        base_url=base_url,
        temperature=0.3,
        num_predict=2048,
    )

    # Build messages
    user_prompt = build_user_prompt(prefecture, sector, predictions, severity_label)
    messages = [
        SystemMessage(content=SYSTEM_PROMPT),
        HumanMessage(content=user_prompt),
    ]

    # Call the LLM
    response = llm.invoke(messages)
    response_text = response.content

    # Parse the JSON response
    parsed = _parse_json_response(response_text)

    # Extract and validate structure
    result = {
        "recommendations": {
            "agentic_ai_solutions": parsed.get("agentic_ai_solutions", []),
            "policy_interventions": parsed.get("policy_interventions", []),
            "business_actions": parsed.get("business_actions", []),
        },
        "reasoning": parsed.get("reasoning", "No reasoning provided."),
    }

    return result
