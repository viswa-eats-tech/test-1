import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  Loader2,
  Bot,
  Landmark,
  Briefcase,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Minus,
  ArrowLeft,
  CheckCircle2,
  Quote,
  Sparkles,
} from "lucide-react";
import { postAgentRecommend } from "../api/client";

const SEVERITY_STYLES = {
  Critical: {
    badge: "bg-red-900/30 border-red-500/50 text-red-400",
    text: "text-red-400",
  },
  Severe: {
    badge: "bg-amber-900/30 border-amber-500/50 text-amber-400",
    text: "text-amber-400",
  },
  Moderate: {
    badge: "bg-blue-900/30 border-blue-500/50 text-blue-400",
    text: "text-blue-400",
  },
  Low: {
    badge: "bg-green-900/30 border-green-500/50 text-green-400",
    text: "text-green-400",
  },
};

const TREND_ICONS = {
  worsening: TrendingUp,
  stable: Minus,
  improving: TrendingDown,
};

const CARDS = [
  {
    key: "agentic_ai_solutions",
    title: "Agentic AI Solutions",
    icon: Bot,
    gradient: "from-purple-600 to-indigo-600",
    bgLight: "bg-purple-900/20",
    iconColor: "text-purple-400",
  },
  {
    key: "policy_interventions",
    title: "Policy Interventions",
    icon: Landmark,
    gradient: "from-amber-600 to-orange-600",
    bgLight: "bg-amber-900/20",
    iconColor: "text-amber-400",
  },
  {
    key: "business_actions",
    title: "Business Actions",
    icon: Briefcase,
    gradient: "from-emerald-600 to-teal-600",
    bgLight: "bg-emerald-900/20",
    iconColor: "text-emerald-400",
  },
];

// Skeleton component for loading state
function Skeleton({ lines = 4 }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: lines }).map((_, i) => (
        <div
          key={i}
          className="h-4 bg-japan-navy-mid/50 rounded animate-pulse"
          style={{ width: `${85 - i * 10}%` }}
        />
      ))}
    </div>
  );
}

export default function Recommendations({
  predictionData,
  selectedPrefecture,
  selectedSector,
}) {
  const [agentResult, setAgentResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!predictionData) return;

    async function fetchRecommendations() {
      setLoading(true);
      setError("");
      try {
        const result = await postAgentRecommend({
          prefecture: selectedPrefecture,
          sector: selectedSector,
          predictions: predictionData.predictions,
          severity_label: predictionData.severity_label,
        });
        setAgentResult(result);
      } catch (err) {
        setError(
          err.response?.data?.detail ||
            "Failed to get AI recommendations. The agent may be unavailable."
        );
      } finally {
        setLoading(false);
      }
    }

    fetchRecommendations();
  }, [predictionData, selectedPrefecture, selectedSector]);

  // No data state
  if (!predictionData) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <AlertTriangle className="w-16 h-16 text-japan-red/50 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-japan-white mb-2">
          No Prediction Data
        </h2>
        <p className="text-slate-400 mb-6">
          Please go to the Dashboard and run an analysis first.
        </p>
        <Link to="/dashboard" className="btn-primary inline-flex items-center gap-2">
          <ArrowLeft className="w-4 h-4" />
          Go to Dashboard
        </Link>
      </div>
    );
  }

  const severity = predictionData.severity_label;
  const trendDir = predictionData.trend;
  const TrendIcon = TREND_ICONS[trendDir] || Minus;
  const sevStyle = SEVERITY_STYLES[severity] || SEVERITY_STYLES.Moderate;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Back link */}
      <Link
        to="/dashboard"
        className="inline-flex items-center gap-1.5 text-sm text-slate-400 hover:text-japan-white mb-6 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Dashboard
      </Link>

      {/* Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-japan-white flex items-center gap-2">
          <Sparkles className="w-6 h-6 text-purple-400" />
          AI Policy Recommendations
        </h1>
        <p className="text-slate-400 mt-1">
          Agentic AI analysis for{" "}
          <span className="text-japan-white font-semibold">{selectedPrefecture}</span>{" "}
          ×{" "}
          <span className="text-japan-white font-semibold">{selectedSector}</span>
        </p>

        {/* Badges */}
        <div className="flex items-center gap-3 mt-4">
          <div
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-sm font-semibold ${sevStyle.badge}`}
          >
            <AlertTriangle className="w-4 h-4" />
            {severity}
          </div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-japan-navy-light border border-japan-navy-mid/50 text-sm text-slate-300">
            <TrendIcon className="w-4 h-4" />
            <span className="capitalize">{trendDir}</span>
          </div>
        </div>
      </div>

      {error && (
        <div className="mb-6 p-4 rounded-lg bg-red-900/30 border border-red-500/50 flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
          <p className="text-red-400 text-sm">{error}</p>
        </div>
      )}

      {/* Recommendation Cards */}
      <div className="grid md:grid-cols-3 gap-6 mb-8">
        {CARDS.map(({ key, title, icon: Icon, gradient, bgLight, iconColor }) => (
          <div
            key={key}
            className="glass-card overflow-hidden animate-fade-in-up"
          >
            {/* Card Header */}
            <div className={`p-4 bg-gradient-to-r ${gradient} flex items-center gap-3`}>
              <Icon className="w-6 h-6 text-white" />
              <h3 className="text-lg font-semibold text-white">{title}</h3>
            </div>

            {/* Card Body */}
            <div className="p-5">
              {loading ? (
                <Skeleton lines={4} />
              ) : agentResult ? (
                <ul className="space-y-3">
                  {(agentResult.recommendations?.[key] || []).map((item, i) => (
                    <li
                      key={i}
                      className={`flex items-start gap-3 p-3 rounded-lg ${bgLight}`}
                    >
                      <CheckCircle2
                        className={`w-5 h-5 ${iconColor} flex-shrink-0 mt-0.5`}
                      />
                      <span className="text-sm text-slate-300 leading-relaxed">
                        {item}
                      </span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-slate-500">No data available.</p>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Reasoning Section */}
      {agentResult?.reasoning && (
        <div className="glass-card p-6 animate-fade-in-up">
          <div className="flex items-center gap-2 mb-4">
            <Quote className="w-5 h-5 text-slate-400" />
            <h3 className="text-lg font-semibold text-japan-white">
              AI Reasoning
            </h3>
          </div>
          <div className="border-l-4 border-japan-red/50 pl-4 py-2">
            <p className="text-slate-300 leading-relaxed italic">
              {agentResult.reasoning}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
