import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Loader2,
  ChevronDown,
  BarChart3,
  TrendingUp,
  TrendingDown,
  Minus,
  AlertTriangle,
  Sparkles,
} from "lucide-react";
import {
  fetchPrefectures,
  fetchSectors,
  postPredict,
  fetchHeatmap,
} from "../api/client";
import JapanMap from "../components/JapanMap";
import PredictionChart from "../components/PredictionChart";

const SEVERITY_STYLES = {
  Critical: "severity-critical pulse-glow-red",
  Severe: "severity-severe",
  Moderate: "severity-moderate",
  Low: "severity-low",
};

const TREND_ICONS = {
  worsening: TrendingUp,
  stable: Minus,
  improving: TrendingDown,
};

export default function Dashboard({
  setPredictionData,
  selectedPrefecture,
  setSelectedPrefecture,
  selectedSector,
  setSelectedSector,
}) {
  const navigate = useNavigate();

  const [prefectures, setPrefectures] = useState([]);
  const [sectors, setSectors] = useState([]);
  const [heatmapData, setHeatmapData] = useState([]);
  const [predictions, setPredictions] = useState(null);
  const [severityLabel, setSeverityLabel] = useState("");
  const [trend, setTrend] = useState("");
  const [loading, setLoading] = useState(false);
  const [mapLoading, setMapLoading] = useState(true);
  const [error, setError] = useState("");

  // Fetch prefectures, sectors, and heatmap data on mount
  useEffect(() => {
    async function loadInitialData() {
      try {
        const [prefs, sects, hmap] = await Promise.all([
          fetchPrefectures(),
          fetchSectors(),
          fetchHeatmap(),
        ]);
        setPrefectures(prefs);
        setSectors(sects);
        setHeatmapData(hmap);
        if (!selectedPrefecture && prefs.length > 0) setSelectedPrefecture(prefs[0]);
        if (!selectedSector && sects.length > 0) setSelectedSector(sects[0]);
      } catch (err) {
        setError("Failed to connect to API. Make sure the backend is running on port 8000.");
      } finally {
        setMapLoading(false);
      }
    }
    loadInitialData();
  }, []);

  // Handle prediction
  const handleAnalyze = async () => {
    if (!selectedPrefecture || !selectedSector) return;
    setLoading(true);
    setError("");
    try {
      const result = await postPredict(selectedPrefecture, selectedSector, [2025, 2035]);
      setPredictions(result.predictions);
      setSeverityLabel(result.severity_label);
      setTrend(result.trend);
      setPredictionData(result);
    } catch (err) {
      setError(err.response?.data?.detail || "Prediction failed. Check backend.");
    } finally {
      setLoading(false);
    }
  };

  const handleGetRecommendations = () => {
    navigate("/recommendations");
  };

  const TrendIcon = TREND_ICONS[trend] || Minus;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-japan-white flex items-center gap-2">
          <BarChart3 className="w-6 h-6 text-japan-red" />
          Labor Shortage Dashboard
        </h1>
        <p className="text-slate-400 mt-1">
          Select a prefecture and sector to predict labor shortage severity
        </p>
      </div>

      {error && (
        <div className="mb-4 p-4 rounded-lg bg-red-900/30 border border-red-500/50 flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
          <p className="text-red-400 text-sm">{error}</p>
        </div>
      )}

      {/* Layout: Controls + Map + Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* ── Left Panel: Controls ────────── */}
        <div className="lg:col-span-3 space-y-4">
          <div className="glass-card p-5 space-y-4">
            <h2 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">
              Configuration
            </h2>

            {/* Prefecture Selector */}
            <div>
              <label className="block text-sm text-slate-400 mb-1.5">Prefecture</label>
              <div className="relative">
                <select
                  value={selectedPrefecture}
                  onChange={(e) => setSelectedPrefecture(e.target.value)}
                  className="input-dark w-full appearance-none pr-10"
                >
                  {prefectures.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
              </div>
            </div>

            {/* Sector Selector */}
            <div>
              <label className="block text-sm text-slate-400 mb-1.5">Industry Sector</label>
              <div className="relative">
                <select
                  value={selectedSector}
                  onChange={(e) => setSelectedSector(e.target.value)}
                  className="input-dark w-full appearance-none pr-10"
                >
                  {sectors.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
              </div>
            </div>

            <button
              onClick={handleAnalyze}
              disabled={loading}
              className="btn-primary w-full flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <BarChart3 className="w-4 h-4" />
                  Analyze
                </>
              )}
            </button>
          </div>

          {/* Severity Summary */}
          {predictions && (
            <div className="glass-card p-5 space-y-3 animate-fade-in-up">
              <h2 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">
                Result Summary
              </h2>

              {/* Severity Badge */}
              <div
                className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border text-sm font-semibold ${
                  SEVERITY_STYLES[severityLabel] || ""
                }`}
              >
                <AlertTriangle className="w-4 h-4" />
                {severityLabel}
              </div>

              {/* Trend */}
              <div className="flex items-center gap-2 text-sm">
                <TrendIcon className="w-4 h-4 text-slate-400" />
                <span className="text-slate-300 capitalize">{trend}</span>
              </div>

              {/* Latest Score */}
              <div className="text-sm text-slate-400">
                Latest Score:{" "}
                <span className="text-japan-white font-bold text-lg">
                  {predictions[predictions.length - 1]?.shortage_index.toFixed(1)}
                </span>
                <span className="text-slate-500"> / 100</span>
              </div>

              {/* Get Recommendations Button */}
              <button
                onClick={handleGetRecommendations}
                className="w-full mt-2 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold transition-all duration-200 shadow-md"
              >
                <Sparkles className="w-4 h-4" />
                Get AI Recommendations
              </button>
            </div>
          )}
        </div>

        {/* ── Center: Japan Map ──────────── */}
        <div className="lg:col-span-5">
          <div className="glass-card p-5 h-full">
            <h2 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-3">
              Prefecture Shortage Heatmap
            </h2>
            {mapLoading ? (
              <div className="flex items-center justify-center h-96">
                <Loader2 className="w-8 h-8 animate-spin text-japan-red" />
              </div>
            ) : (
              <JapanMap
                heatmapData={heatmapData}
                selectedPrefecture={selectedPrefecture}
                onPrefectureClick={(pref) => setSelectedPrefecture(pref)}
              />
            )}
          </div>
        </div>

        {/* ── Right Panel: Chart ─────────── */}
        <div className="lg:col-span-4">
          <div className="glass-card p-5 h-full">
            <h2 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-3">
              Shortage Forecast (2025–2035)
            </h2>
            {predictions ? (
              <PredictionChart
                predictions={predictions}
                severityLabel={severityLabel}
              />
            ) : (
              <div className="flex flex-col items-center justify-center h-80 text-slate-500">
                <BarChart3 className="w-12 h-12 mb-3 opacity-30" />
                <p className="text-sm">Select a prefecture & sector and click Analyze</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
