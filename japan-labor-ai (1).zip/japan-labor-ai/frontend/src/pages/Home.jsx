import React from "react";
import { Link } from "react-router-dom";
import {
  Brain,
  Map,
  TrendingUp,
  Users,
  BarChart3,
  Zap,
  ArrowRight,
  Activity,
} from "lucide-react";

const STATS = [
  { value: "31.4%", label: "Population Over 65", icon: Users },
  { value: "11M", label: "Projected Worker Shortfall by 2040", icon: TrendingUp },
  { value: "47", label: "Prefectures Analyzed", icon: Map },
  { value: "10", label: "Industry Sectors", icon: BarChart3 },
];

const FEATURES = [
  {
    icon: Brain,
    title: "ML Predictions",
    desc: "XGBoost regression and Prophet time-series models trained on prefecture × sector labor data to forecast shortage severity from 2025 to 2035.",
    gradient: "from-red-600 to-rose-700",
  },
  {
    icon: Map,
    title: "Interactive Heatmap",
    desc: "D3.js choropleth map of Japan\'s 47 prefectures, color-coded by labor shortage severity. Click any prefecture for detailed analysis.",
    gradient: "from-blue-600 to-indigo-700",
  },
  {
    icon: Zap,
    title: "AI Policy Advisor",
    desc: "LangChain + Ollama agentic AI layer that reasons about predictions and generates actionable policy, business, and AI automation recommendations.",
    gradient: "from-amber-600 to-orange-700",
  },
];

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* ── Hero ────────────────────────────── */}
      <section className="relative overflow-hidden">
        {/* Background gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-japan-navy via-japan-navy-light to-japan-navy opacity-80" />
        <div className="absolute inset-0">
          <div className="absolute top-20 left-10 w-72 h-72 bg-japan-red/10 rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="text-center animate-fade-in-up">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-japan-red/10 border border-japan-red/30 mb-6">
              <Activity className="w-4 h-4 text-japan-red" />
              <span className="text-sm font-medium text-japan-red">
                Accenture GenAI Internship Project
              </span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight">
              <span className="text-japan-white">Japan Labor Crisis</span>
              <br />
              <span className="bg-gradient-to-r from-japan-red to-amber-500 bg-clip-text text-transparent">
                Predictor & AI Advisor
              </span>
            </h1>

            <p className="mt-6 max-w-3xl mx-auto text-lg sm:text-xl text-slate-400 leading-relaxed">
              Japan faces a structural labor crisis — 31.4% of its population is over 65,
              the birth rate hovers at 1.3, and{" "}
              <span className="text-japan-white font-semibold">
                11 million workers will be needed by 2040
              </span>
              . This tool combines machine learning forecasting with an agentic AI advisor
              to predict sector-level shortfalls and recommend actionable interventions.
            </p>

            <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/dashboard" className="btn-primary flex items-center gap-2 text-lg">
                Open Dashboard
                <ArrowRight className="w-5 h-5" />
              </Link>
              <a
                href="https://www.e-stat.go.jp/en"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-secondary flex items-center gap-2"
              >
                View Data Sources
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ── Stats ───────────────────────────── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {STATS.map(({ value, label, icon: Icon }) => (
            <div
              key={label}
              className="glass-card p-5 text-center hover:border-japan-red/30 transition-all duration-300"
            >
              <Icon className="w-6 h-6 text-japan-red mx-auto mb-2" />
              <div className="text-2xl sm:text-3xl font-bold text-japan-white">
                {value}
              </div>
              <div className="text-sm text-slate-400 mt-1">{label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Features ────────────────────────── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-japan-white">How It Works</h2>
          <p className="text-slate-400 mt-3 max-w-2xl mx-auto">
            Three powerful layers working together to analyze Japan\'s labor future
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {FEATURES.map(({ icon: Icon, title, desc, gradient }) => (
            <div
              key={title}
              className="glass-card overflow-hidden group hover:scale-[1.02] transition-transform duration-300"
            >
              <div className={`p-4 bg-gradient-to-r ${gradient}`}>
                <Icon className="w-8 h-8 text-white" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-japan-white mb-2">
                  {title}
                </h3>
                <p className="text-slate-400 leading-relaxed text-sm">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Tech Stack ──────────────────────── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="glass-card p-8">
          <h2 className="text-2xl font-bold text-japan-white mb-6 text-center">
            Technology Stack
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 text-center">
            {[
              "FastAPI",
              "XGBoost",
              "Prophet",
              "LangChain + Ollama",
              "React + Vite",
              "D3.js + Recharts",
            ].map((tech) => (
              <div
                key={tech}
                className="px-3 py-3 rounded-lg bg-japan-navy border border-japan-navy-mid/50 text-sm font-medium text-slate-300"
              >
                {tech}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Footer ──────────────────────────── */}
      <footer className="border-t border-japan-navy-mid/50 py-8">
        <div className="max-w-7xl mx-auto px-4 text-center text-sm text-slate-500">
          Built for Accenture Generative AI Internship • Data from e-Stat, RESAS, JILPT, World Bank
        </div>
      </footer>
    </div>
  );
}
