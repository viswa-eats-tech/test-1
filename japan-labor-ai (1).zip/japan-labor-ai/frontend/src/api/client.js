import axios from "axios";

const API_BASE = "http://localhost:8000";

const api = axios.create({
  baseURL: API_BASE,
  headers: { "Content-Type": "application/json" },
  timeout: 60000, // 60s for agent calls
});

/**
 * Fetch all 47 Japanese prefectures.
 */
export async function fetchPrefectures() {
  const { data } = await api.get("/prefectures");
  return data;
}

/**
 * Fetch all industry sectors.
 */
export async function fetchSectors() {
  const { data } = await api.get("/sectors");
  return data;
}

/**
 * Post a prediction request.
 * @param {string} prefecture
 * @param {string} sector
 * @param {number[]} yearRange - [startYear, endYear]
 * @returns {{ predictions, severity_label, trend }}
 */
export async function postPredict(prefecture, sector, yearRange) {
  const { data } = await api.post("/predict", {
    prefecture,
    sector,
    year_range: yearRange,
  });
  return data;
}

/**
 * Post a recommendation request to the AI agent.
 * @param {object} payload - { prefecture, sector, predictions, severity_label }
 * @returns {{ recommendations, reasoning }}
 */
export async function postAgentRecommend(payload) {
  const { data } = await api.post("/agent/recommend", payload);
  return data;
}

/**
 * Fetch heatmap data (shortage_index per prefecture).
 * @returns {Array<{ prefecture, shortage_index }>}
 */
export async function fetchHeatmap() {
  const { data } = await api.get("/heatmap");
  return data;
}

export default api;
