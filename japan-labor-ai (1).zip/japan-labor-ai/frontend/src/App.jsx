import React, { useState } from "react";
import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Recommendations from "./pages/Recommendations";

export default function App() {
  // Shared state between Dashboard and Recommendations
  const [predictionData, setPredictionData] = useState(null);
  const [selectedPrefecture, setSelectedPrefecture] = useState("");
  const [selectedSector, setSelectedSector] = useState("");

  return (
    <div className="min-h-screen bg-japan-navy">
      <Navbar />
      <main className="pt-16">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route
            path="/dashboard"
            element={
              <Dashboard
                setPredictionData={setPredictionData}
                selectedPrefecture={selectedPrefecture}
                setSelectedPrefecture={setSelectedPrefecture}
                selectedSector={selectedSector}
                setSelectedSector={setSelectedSector}
              />
            }
          />
          <Route
            path="/recommendations"
            element={
              <Recommendations
                predictionData={predictionData}
                selectedPrefecture={selectedPrefecture}
                selectedSector={selectedSector}
              />
            }
          />
        </Routes>
      </main>
    </div>
  );
}
