import React from "react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from "recharts";

const SEVERITY_COLORS = {
  Critical: { line: "#ef4444", fill: "#ef4444" },
  Severe: { line: "#f59e0b", fill: "#f59e0b" },
  Moderate: { line: "#3b82f6", fill: "#3b82f6" },
  Low: { line: "#22c55e", fill: "#22c55e" },
};

const THRESHOLDS = [
  { y: 70, label: "Critical", color: "#ef4444" },
  { y: 50, label: "Severe", color: "#f59e0b" },
  { y: 30, label: "Moderate", color: "#3b82f6" },
];

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload || !payload.length) return null;

  const value = payload[0].value;
  let severity = "Low";
  if (value >= 70) severity = "Critical";
  else if (value >= 50) severity = "Severe";
  else if (value >= 30) severity = "Moderate";

  const color = SEVERITY_COLORS[severity]?.line || "#3b82f6";

  return (
    <div className="bg-japan-navy/95 border border-japan-navy-mid backdrop-blur-md rounded-lg p-3 shadow-xl">
      <p className="text-slate-400 text-xs font-medium">Year {label}</p>
      <p className="text-lg font-bold" style={{ color }}>
        {value.toFixed(1)}
        <span className="text-slate-500 text-sm font-normal"> / 100</span>
      </p>
      <p className="text-xs mt-1" style={{ color }}>
        {severity}
      </p>
    </div>
  );
}

export default function PredictionChart({ predictions = [], severityLabel = "Moderate" }) {
  const colors = SEVERITY_COLORS[severityLabel] || SEVERITY_COLORS.Moderate;

  return (
    <div className="w-full h-80">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart
          data={predictions}
          margin={{ top: 10, right: 10, left: -10, bottom: 0 }}
        >
          <defs>
            <linearGradient id="colorShortage" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={colors.fill} stopOpacity={0.3} />
              <stop offset="95%" stopColor={colors.fill} stopOpacity={0.02} />
            </linearGradient>
          </defs>

          <CartesianGrid
            strokeDasharray="3 3"
            stroke="#1e293b"
            vertical={false}
          />

          <XAxis
            dataKey="year"
            tick={{ fill: "#94a3b8", fontSize: 12 }}
            axisLine={{ stroke: "#334155" }}
            tickLine={{ stroke: "#334155" }}
          />

          <YAxis
            domain={[0, 100]}
            tick={{ fill: "#94a3b8", fontSize: 12 }}
            axisLine={{ stroke: "#334155" }}
            tickLine={{ stroke: "#334155" }}
            label={{
              value: "Shortage Index",
              angle: -90,
              position: "insideLeft",
              offset: 20,
              style: { fill: "#64748b", fontSize: 12 },
            }}
          />

          <Tooltip content={<CustomTooltip />} />

          {/* Threshold reference lines */}
          {THRESHOLDS.map(({ y, label, color }) => (
            <ReferenceLine
              key={y}
              y={y}
              stroke={color}
              strokeDasharray="4 4"
              strokeOpacity={0.3}
              label={{
                value: label,
                position: "right",
                fill: color,
                fontSize: 10,
                opacity: 0.6,
              }}
            />
          ))}

          <Area
            type="monotone"
            dataKey="shortage_index"
            stroke={colors.line}
            strokeWidth={2.5}
            fill="url(#colorShortage)"
            dot={{
              r: 3,
              fill: colors.line,
              stroke: "#0f172a",
              strokeWidth: 2,
            }}
            activeDot={{
              r: 6,
              fill: colors.line,
              stroke: "#ffffff",
              strokeWidth: 2,
            }}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
