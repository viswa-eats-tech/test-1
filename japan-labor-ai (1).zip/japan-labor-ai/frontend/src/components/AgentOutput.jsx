import React from "react";
import { Bot, Landmark, Briefcase, CheckCircle2 } from "lucide-react";

const SECTIONS = [
  {
    key: "agentic_ai_solutions",
    title: "AI Solutions",
    icon: Bot,
    color: "text-purple-400",
    bg: "bg-purple-900/20",
  },
  {
    key: "policy_interventions",
    title: "Policy",
    icon: Landmark,
    color: "text-amber-400",
    bg: "bg-amber-900/20",
  },
  {
    key: "business_actions",
    title: "Business",
    icon: Briefcase,
    color: "text-emerald-400",
    bg: "bg-emerald-900/20",
  },
];

/**
 * Compact agent output widget — can be embedded in Dashboard or used standalone.
 */
export default function AgentOutput({ recommendations = {}, reasoning = "" }) {
  return (
    <div className="space-y-4">
      {SECTIONS.map(({ key, title, icon: Icon, color, bg }) => {
        const items = recommendations[key] || [];
        if (items.length === 0) return null;
        return (
          <div key={key}>
            <div className="flex items-center gap-2 mb-2">
              <Icon className={`w-4 h-4 ${color}`} />
              <h4 className={`text-sm font-semibold ${color}`}>{title}</h4>
            </div>
            <ul className="space-y-1.5">
              {items.map((item, i) => (
                <li
                  key={i}
                  className={`flex items-start gap-2 p-2 rounded-md ${bg} text-xs text-slate-300`}
                >
                  <CheckCircle2
                    className={`w-3.5 h-3.5 ${color} flex-shrink-0 mt-0.5`}
                  />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        );
      })}

      {reasoning && (
        <div className="border-l-2 border-japan-navy-mid pl-3 mt-3">
          <p className="text-xs text-slate-500 italic leading-relaxed">
            {reasoning}
          </p>
        </div>
      )}
    </div>
  );
}
