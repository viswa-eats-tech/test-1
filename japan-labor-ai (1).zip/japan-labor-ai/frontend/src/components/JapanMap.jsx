import React, { useEffect, useRef, useState } from "react";
import * as d3 from "d3";

// Mapping from GeoJSON prefecture names to our data names
// The GeoJSON from dataofjapan uses slightly different romanization in some cases
const GEOJSON_NAME_MAP = {
  "Hokkaido": "Hokkaido",
  "Aomori": "Aomori",
  "Iwate": "Iwate",
  "Miyagi": "Miyagi",
  "Akita": "Akita",
  "Yamagata": "Yamagata",
  "Fukushima": "Fukushima",
  "Ibaraki": "Ibaraki",
  "Tochigi": "Tochigi",
  "Gunma": "Gunma",
  "Saitama": "Saitama",
  "Chiba": "Chiba",
  "Tokyo": "Tokyo",
  "Kanagawa": "Kanagawa",
  "Niigata": "Niigata",
  "Toyama": "Toyama",
  "Ishikawa": "Ishikawa",
  "Fukui": "Fukui",
  "Yamanashi": "Yamanashi",
  "Nagano": "Nagano",
  "Gifu": "Gifu",
  "Shizuoka": "Shizuoka",
  "Aichi": "Aichi",
  "Mie": "Mie",
  "Shiga": "Shiga",
  "Kyoto": "Kyoto",
  "Osaka": "Osaka",
  "Hyogo": "Hyogo",
  "Nara": "Nara",
  "Wakayama": "Wakayama",
  "Tottori": "Tottori",
  "Shimane": "Shimane",
  "Okayama": "Okayama",
  "Hiroshima": "Hiroshima",
  "Yamaguchi": "Yamaguchi",
  "Tokushima": "Tokushima",
  "Kagawa": "Kagawa",
  "Ehime": "Ehime",
  "Kochi": "Kochi",
  "Fukuoka": "Fukuoka",
  "Saga": "Saga",
  "Nagasaki": "Nagasaki",
  "Kumamoto": "Kumamoto",
  "Oita": "Oita",
  "Miyazaki": "Miyazaki",
  "Kagoshima": "Kagoshima",
  "Okinawa": "Okinawa",
};

const GEOJSON_URL =
  "https://raw.githubusercontent.com/dataofjapan/land/master/japan.geojson";

export default function JapanMap({
  heatmapData = [],
  selectedPrefecture = "",
  onPrefectureClick = () => {},
}) {
  const svgRef = useRef(null);
  const tooltipRef = useRef(null);
  const [geoData, setGeoData] = useState(null);
  const [loadError, setLoadError] = useState(false);

  // Fetch GeoJSON once
  useEffect(() => {
    fetch(GEOJSON_URL)
      .then((res) => {
        if (!res.ok) throw new Error("GeoJSON fetch failed");
        return res.json();
      })
      .then(setGeoData)
      .catch(() => setLoadError(true));
  }, []);

  // Draw map
  useEffect(() => {
    if (!geoData || !svgRef.current) return;

    const container = svgRef.current.parentElement;
    const width = container.clientWidth || 500;
    const height = Math.max(width * 1.0, 420);

    // Build lookup from heatmapData
    const dataMap = {};
    heatmapData.forEach((d) => {
      dataMap[d.prefecture] = d.shortage_index;
    });

    // Color scale: 0 (green) → 80+ (red)
    const colorScale = d3
      .scaleSequential(d3.interpolateRdYlGn)
      .domain([80, 0]);

    const svg = d3
      .select(svgRef.current)
      .attr("width", width)
      .attr("height", height)
      .attr("viewBox", `0 0 ${width} ${height}`);

    svg.selectAll("*").remove();

    // Projection
    const projection = d3
      .geoMercator()
      .center([137, 38])
      .scale(width * 2.8)
      .translate([width / 2, height / 2.2]);

    const path = d3.geoPath().projection(projection);

    // Tooltip
    const tooltip = d3.select(tooltipRef.current);

    // Draw prefectures
    svg
      .selectAll("path")
      .data(geoData.features)
      .enter()
      .append("path")
      .attr("d", path)
      .attr("fill", (d) => {
        const geoName = d.properties.name || d.properties.nam || "";
        const dataName = GEOJSON_NAME_MAP[geoName] || geoName;
        const value = dataMap[dataName];
        return value !== undefined ? colorScale(value) : "#334155";
      })
      .attr("stroke", (d) => {
        const geoName = d.properties.name || d.properties.nam || "";
        const dataName = GEOJSON_NAME_MAP[geoName] || geoName;
        return dataName === selectedPrefecture ? "#ffffff" : "#1e293b";
      })
      .attr("stroke-width", (d) => {
        const geoName = d.properties.name || d.properties.nam || "";
        const dataName = GEOJSON_NAME_MAP[geoName] || geoName;
        return dataName === selectedPrefecture ? 2.5 : 0.5;
      })
      .style("cursor", "pointer")
      .on("mouseover", function (event, d) {
        const geoName = d.properties.name || d.properties.nam || "";
        const dataName = GEOJSON_NAME_MAP[geoName] || geoName;
        const value = dataMap[dataName];

        d3.select(this)
          .attr("stroke", "#ffffff")
          .attr("stroke-width", 2);

        tooltip
          .style("display", "block")
          .html(
            `<strong>${dataName}</strong><br/>Shortage: ${
              value !== undefined ? value.toFixed(1) : "N/A"
            }/100`
          );
      })
      .on("mousemove", function (event) {
        tooltip
          .style("left", event.offsetX + 12 + "px")
          .style("top", event.offsetY - 28 + "px");
      })
      .on("mouseout", function (event, d) {
        const geoName = d.properties.name || d.properties.nam || "";
        const dataName = GEOJSON_NAME_MAP[geoName] || geoName;

        d3.select(this)
          .attr("stroke", dataName === selectedPrefecture ? "#ffffff" : "#1e293b")
          .attr("stroke-width", dataName === selectedPrefecture ? 2.5 : 0.5);

        tooltip.style("display", "none");
      })
      .on("click", function (event, d) {
        const geoName = d.properties.name || d.properties.nam || "";
        const dataName = GEOJSON_NAME_MAP[geoName] || geoName;
        onPrefectureClick(dataName);
      });

    // ── Legend ───────────────────────────────
    const legendWidth = Math.min(width - 40, 250);
    const legendHeight = 12;
    const legendX = (width - legendWidth) / 2;
    const legendY = height - 35;

    const defs = svg.append("defs");
    const gradient = defs
      .append("linearGradient")
      .attr("id", "legend-gradient");

    const steps = 10;
    for (let i = 0; i <= steps; i++) {
      gradient
        .append("stop")
        .attr("offset", `${(i / steps) * 100}%`)
        .attr("stop-color", colorScale((i / steps) * 80));
    }

    svg
      .append("rect")
      .attr("x", legendX)
      .attr("y", legendY)
      .attr("width", legendWidth)
      .attr("height", legendHeight)
      .attr("rx", 3)
      .style("fill", "url(#legend-gradient)");

    // Legend labels
    svg
      .append("text")
      .attr("x", legendX)
      .attr("y", legendY + legendHeight + 14)
      .attr("fill", "#94a3b8")
      .attr("font-size", "10px")
      .text("Low (0)");

    svg
      .append("text")
      .attr("x", legendX + legendWidth)
      .attr("y", legendY + legendHeight + 14)
      .attr("fill", "#94a3b8")
      .attr("font-size", "10px")
      .attr("text-anchor", "end")
      .text("Critical (80+)");
  }, [geoData, heatmapData, selectedPrefecture, onPrefectureClick]);

  if (loadError) {
    return (
      <div className="flex flex-col items-center justify-center h-80 text-slate-500">
        <p className="text-sm">
          Unable to load Japan map. Please check your internet connection.
        </p>
        <p className="text-xs mt-1 text-slate-600">
          GeoJSON source: dataofjapan/land
        </p>
      </div>
    );
  }

  return (
    <div className="relative w-full">
      <svg ref={svgRef} className="w-full" />
      <div
        ref={tooltipRef}
        className="map-tooltip"
        style={{ display: "none" }}
      />
    </div>
  );
}
