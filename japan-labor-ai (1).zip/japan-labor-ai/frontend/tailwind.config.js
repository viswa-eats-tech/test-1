/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        japan: {
          navy: "#0f172a",
          "navy-light": "#1e293b",
          "navy-mid": "#334155",
          red: "#dc2626",
          "red-dark": "#991b1b",
          crimson: "#b91c1c",
          gold: "#f59e0b",
          sakura: "#f9a8d4",
          white: "#f8fafc",
        },
      },
      fontFamily: {
        sans: ['"Inter"', '"Noto Sans JP"', "sans-serif"],
      },
    },
  },
  plugins: [],
};
