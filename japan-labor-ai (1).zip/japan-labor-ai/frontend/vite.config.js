import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/prefectures": "http://localhost:8000",
      "/sectors": "http://localhost:8000",
      "/predict": "http://localhost:8000",
      "/agent": "http://localhost:8000",
      "/heatmap": "http://localhost:8000",
    },
  },
});
