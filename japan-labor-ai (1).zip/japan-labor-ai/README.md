# 🇯🇵 Japan Labor Crisis Predictor & Agentic Policy Advisor

> **Accenture Generative AI Internship Project**
>
> A full-stack web application that uses **machine learning** and an **agentic AI layer** to predict Japan's sector-level labor shortages per prefecture and recommend actionable interventions for businesses and policymakers.

---

## 📋 Problem Statement

Japan faces a structural labor crisis:
- **31.4%** of the population is over age 65 (by 2025)
- Birth rate has dropped to **1.3**
- **11 million worker shortfall** projected by 2040

This tool provides:
1. **ML-powered predictions** of labor shortage severity by prefecture × sector (2025–2035)
2. **Agentic AI recommendations** for AI solutions, policy interventions, and business actions

---

## 🏗️ Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                        FRONTEND                              │
│    React + Vite │ D3.js (Map) │ Recharts │ Tailwind CSS      │
└───────────────────────┬──────────────────────────────────────┘
                        │  REST API (JSON)
                        ▼
┌──────────────────────────────────────────────────────────────┐
│                    BACKEND (FastAPI)                          │
│  ┌─────────────┐  ┌──────────────┐  ┌─────────────────────┐ │
│  │ /predict     │  │ /heatmap     │  │ /agent/recommend    │ │
│  │ XGBoost +    │  │ Aggregated   │  │ LangChain + Ollama  │ │
│  │ Prophet      │  │ shortage data│  │ (llama3.1/mistral)  │ │
│  └──────┬───── ┘  └──────┬──────┘  └──────────┬──────────┘ │
│         │                 │                     │            │
│         ▼                 ▼                     ▼            │
│  ┌──────────────────────────────┐   ┌────────────────────┐  │
│  │  Data Layer (CSV + SQLite)   │   │  Ollama (Local LLM)│  │
│  │  Trained Models (.pkl)       │   │  llama3.1 / mistral│  │
│  └──────────────────────────────┘   └────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

---

## 🛠️ Tech Stack

| Layer            | Technology                          |
|------------------|-------------------------------------|
| **Backend**      | Python, FastAPI, Uvicorn            |
| **ML Models**    | XGBoost, Prophet, scikit-learn      |
| **Agent Layer**  | LangChain + Ollama (local LLM)     |
| **Frontend**     | React (Vite), Tailwind CSS          |
| **Visualization**| D3.js (choropleth), Recharts        |
| **Database**     | SQLite (SQLAlchemy) + CSV           |
| **No Paid APIs** | Everything runs locally             |

---

## 🚀 Setup Instructions

### Prerequisites

- **Python** 3.10+ with pip
- **Node.js** 18+ with npm
- **Ollama** (for the AI agent) — [install from ollama.ai](https://ollama.ai)

### Step 1: Clone the Project

```bash
cd japan-labor-ai
```

### Step 2: Backend Setup

```bash
cd backend

# Create a virtual environment (recommended)
python -m venv venv
source venv/bin/activate        # macOS/Linux
# venv\Scripts\activate         # Windows

# Install dependencies
pip install -r requirements.txt
```

### Step 3: Generate Data & Train Models

```bash
# Generate synthetic labor data (47 prefectures × 10 sectors × 19 years)
python data/generate_synthetic_data.py

# Train XGBoost model
python models/train_xgboost.py

# Train Prophet models (one per sector)
python models/train_prophet.py
```

### Step 4: Set Up Ollama (Optional — for AI Agent)

```bash
# Install Ollama from https://ollama.ai
# Then pull a model:
ollama pull llama3.1
# OR
ollama pull mistral

# The Ollama server runs on http://localhost:11434 by default
```

> **Note:** If Ollama is not running, the app falls back to a built-in rule-based recommendation engine. The app works fully without Ollama.

### Step 5: Start the Backend

```bash
# From the backend/ directory
python main.py
# OR
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

The API will be available at `http://localhost:8000`. Visit `http://localhost:8000/docs` for the Swagger UI.

### Step 6: Frontend Setup

```bash
# From the project root
cd frontend

# Install dependencies
npm install

# Start dev server
npm run dev
```

The frontend will be available at `http://localhost:5173`.

---

## 📡 API Endpoints

| Method | Endpoint             | Description                                      |
|--------|----------------------|--------------------------------------------------|
| GET    | `/prefectures`       | Returns list of all 47 Japanese prefectures      |
| GET    | `/sectors`           | Returns list of 10 industry sectors              |
| POST   | `/predict`           | Predict shortage_index for prefecture × sector   |
| POST   | `/agent/recommend`   | Get AI agent recommendations                     |
| GET    | `/heatmap`           | Get shortage_index for all prefectures           |

### POST `/predict` — Request Body
```json
{
  "prefecture": "Aichi",
  "sector": "Healthcare",
  "year_range": [2025, 2035]
}
```

### POST `/agent/recommend` — Request Body
```json
{
  "prefecture": "Aichi",
  "sector": "Healthcare",
  "predictions": [{"year": 2025, "shortage_index": 45.2}, ...],
  "severity_label": "Severe"
}
```

---

## 📁 Project Structure

```
japan-labor-ai/
├── backend/
│   ├── main.py                    # FastAPI application
│   ├── database.py                # SQLAlchemy + SQLite
│   ├── requirements.txt           # Python dependencies
│   ├── models/
│   │   ├── train_xgboost.py       # XGBoost training script
│   │   ├── train_prophet.py       # Prophet training script
│   │   └── predict.py             # Prediction utilities
│   ├── agent/
│   │   ├── advisor_agent.py       # LangChain + Ollama integration
│   │   └── prompts.py             # System/user prompts
│   └── data/
│       ├── generate_synthetic_data.py
│       ├── raw/                   # Raw downloaded CSVs
│       ├── processed/             # Cleaned labor_data.csv
│       └── models/                # Saved .pkl model files
├── frontend/
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Home.jsx           # Landing page
│   │   │   ├── Dashboard.jsx      # Main dashboard
│   │   │   └── Recommendations.jsx # AI recommendations
│   │   ├── components/
│   │   │   ├── JapanMap.jsx       # D3 choropleth map
│   │   │   ├── PredictionChart.jsx # Recharts line chart
│   │   │   ├── AgentOutput.jsx    # Recommendation cards
│   │   │   └── Navbar.jsx         # Navigation bar
│   │   ├── api/
│   │   │   └── client.js          # Axios API client
│   │   ├── App.jsx                # React routes
│   │   ├── main.jsx               # Entry point
│   │   └── index.css              # Tailwind + custom styles
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js
│   ├── tailwind.config.js
│   └── postcss.config.js
└── README.md
```

---

## 🤖 ML Model Details

### XGBoost Regression
- **Target:** `shortage_index` (0–100 severity score)
- **Features:** year, prefecture (encoded), sector (encoded), population_65plus_pct, birth_rate, labor_force_participation_rate, job_openings_ratio
- **Formula:** `shortage_index = job_openings_ratio × (1 - LFPR) × aging_factor`, normalized 0–100
- **Split:** 80/20 train-test
- **Metrics:** RMSE and R²

### Prophet Time-Series
- **One model per sector** for trend forecasting
- **Forecast horizon:** 2024–2035
- **Provides:** confidence intervals (upper/lower bounds)

---

## 📊 Data Sources

| Source | Description | URL |
|--------|-------------|-----|
| **e-Stat** | Japan Statistics Bureau — Labour Force Survey | https://www.e-stat.go.jp/en |
| **RESAS API** | Regional Economic Society Analyzing System | https://opendata.resas-portal.go.jp |
| **JILPT** | Japan Institute for Labour Policy and Training | https://www.jil.go.jp/english/ |
| **World Bank** | Japan aging & labor indicators | https://data.worldbank.org |
| **Kaggle** | Japan census & labor datasets | https://www.kaggle.com |

> The app includes a synthetic data generator (`generate_synthetic_data.py`) that creates realistic data mirroring these sources. You can replace it with real downloaded data.

---

## 🎨 Features

- **Interactive D3 choropleth map** of Japan's 47 prefectures, color-coded by shortage severity
- **Time-series forecast chart** with severity thresholds and trend indicators
- **Agentic AI recommendations** powered by LangChain + Ollama (llama3.1/mistral)
- **Rule-based fallback** when Ollama is unavailable
- **Dark theme** with Japanese-inspired design (navy backgrounds, red accents)
- **Fully responsive** — works on desktop and mobile
- **No paid APIs** — everything runs locally

---

## 📝 License

Built for the Accenture Generative AI Internship. For educational and demonstration purposes.

---

<p align="center">
  <strong>🇯🇵 日本の労働危機に AI で立ち向かう</strong><br/>
  <em>Confronting Japan's labor crisis with AI</em>
</p>
